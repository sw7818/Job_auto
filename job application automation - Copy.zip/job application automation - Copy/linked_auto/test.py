test = 'Applied'

test_1 = test.lower()

if 'applied' in test_1:
    print('looooooooool')
