dict = {'python': 3, 'word': 10,
        'javascript': 1, 'django': 1, 'react': 1, 'excel': 5}


def reply(Question):
    question1 = Question.lower()
    p = 1

    if 'how many years' in question1:
        if 'python' in question1:
            p = dict.get('python')
            return p

        if 'microsoft word' in question1:
            p = dict.get('word')
            return p

        if 'excel' in question1:
            p = dict.get('excel')
            return p

        if 'javascript' in question1:
            p = dict.get('javascript')
            return p

        if 'django' in question1:
            p = dict.get('django')
            return p

        if 'react' in question1:
            p = dict.get('react')
            return p

        else:
            p = 1
            return str(p)

    if 'are you' or 'have you' in question1:
        p = ' j fglnsf;lg'

        return p


print(reply('Have you excel'))
